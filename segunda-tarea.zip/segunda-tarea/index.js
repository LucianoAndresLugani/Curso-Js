let nombre = "Luciano Andres Lugani";
let edad = 28;
let soyDesarrollador = true

let fecha = new Date()

const fecha_de_nacimiento = new Date(1994,8,30);

const libro = {
    titulo:"Pensar Rapido Pensar despacio",
    autor: "Daniel Kanneman",
    fecha: "13/02/2018",
}

console.log(nombre);
console.log(edad);
console.log(soyDesarrollador);
console.log(fecha_de_nacimiento);

console.log(libro.autor);
console.log(libro.titulo);
console.log(libro.fecha);